import { modifier } from 'ember-modifier';

export default modifier(function wcCatchEvent(element/*, positional, named*/) {
  console.log(element, "=====aa")
});
