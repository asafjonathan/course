import Model, { attr } from '@ember-data/model';

export default class ProductModel extends Model {
  @attr('string') title;
  @attr('string') image;
  @attr('number') likes;
  @attr('string') created_at;
  @attr('string') updated_at;
}
