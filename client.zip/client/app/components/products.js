import Component from '@glimmer/component';
import { action } from '@ember/object';
import { inject as service } from '@ember/service';
import { tracked } from '@glimmer/tracking'

export default class ProductsComponent extends Component {
  @service store;
  @tracked query = 'Search...'; 
  @service router;

  constructor(){
    super(...arguments);
   
    
  }
 
  @action
  async doLike(productId) {
    await fetch(`http://localhost:3001/products/like/${productId}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    }).catch((err) => {
    }).then(()=>{
     const product = this.store.peekRecord('product', productId);
     product.set('likes' , product.get('likes') + 1); 
    });
  }
   
  @action
   search(event) {
    this.query = event.target.value;
    this.router.transitionTo({ queryParams: { query: this.query }});     
  }
  @action
  onFocus (){
    this.query = '';
  }
  @action 
  loadComponent(element) {
    console.log(element, "==element")
    // You have the canvas element. Now make the graph!
  }

}
