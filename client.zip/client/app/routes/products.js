import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
export default class ProductsRoute extends Route {
  
  @service store;

  queryParams = {
    query: { refreshModel: true },
  };

  async model(params) {
    let products = null;
    if (params && params.query && params.query.length > 0){
        products =  this.store.peekAll('product').filterBy('title', params.query);
    }else{
      products =  this.store.peekAll('product');
    }
    const data = products && products.length > 0 ? products : await this.store.findAll('product');
    return  data;
  }

 
}
