import JSONAPIAdapter from '@ember-data/adapter/rest';

export default class ApplicaationAdapter extends JSONAPIAdapter {
  host = 'http://localhost:3000';
}
